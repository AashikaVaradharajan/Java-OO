package Server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/***********************************
 * @author Bansari Patel
 *
 **********************************/
public class AdminInventoryModel {


	public AdminInventoryModel() {


		
	}
	
	public void viewInventory() {
		
		List<Product> list = getAdminInventory(); 
		System.out.println("This is AdminInventory Model"); 
        for (Product Item:list) { 
            
           System.out.println("Item_ID: " + Item.getProductID() ); 
           System.out.print("\tType: " + Item.getType() ); 
           System.out.print("\tName: " + Item.getProductName() ); 
           System.out.print("\tPrice: " + Item.getProductPrice() ); 
           System.out.print("\tQuantity: " + Item.getProductQty() ); 
           System.out.print("\tUnit: " + Item.getMeasuredUnit() ); 
           
        } 
		
	}
	
	private List<Product> getAdminInventory(){

		int ItemID;
		String Type;
		String ProductName;
		float ProductPrice;
		int ProductQty;
		String MeasuredUnit;
		
		List<Product> list = new ArrayList<Product>();
		
		Connection connection = null;
		Statement statement = null;
		ResultSet AdminResultSet = null;
		
		try {

			System.out.println("Trying to establish the connection"); 
			//establishing connection
			connection = DatabaseConnection.createConnection();

			System.out.println("Trying to create a statement"); 
			//Statement is used to write queries. Read more about it.
			statement = connection.createStatement();

			System.out.println("Trying to get the result set"); 
			//Fetching all the records and storing in a resultSet.
			AdminResultSet = statement.executeQuery("SELECT * FROM Item");
			
			while(AdminResultSet.next()) {
				
				ItemID = AdminResultSet.getInt("Item_ID");
				Type = AdminResultSet.getString("Type");
				ProductName = AdminResultSet.getString("Description");
				ProductPrice = AdminResultSet.getFloat("Price");
				ProductQty = AdminResultSet.getInt("Quantity");
				MeasuredUnit = AdminResultSet.getString("Unit");
				
				Product item = new Product();
				item.setProductID(ItemID);
				item.setType(Type);
				item.setProductName(ProductName);
				item.setProductPrice(ProductPrice);
				item.setProductQty(ProductQty);
				item.setMeasuredUnit(MeasuredUnit);
				
				list.add(item);
								
			}
			
			AdminResultSet.close();
			
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
		return list;
		
	}

	public void AddNewItem(Product NewProduct) {
		
		int ItemID = NewProduct.getProductID();
		String Type = NewProduct.getType();
		String ProductName = NewProduct.getProductName();
		float ProductPrice = NewProduct.getProductPrice();
		int ProductQty = NewProduct.getProductQty();
		String MeasuredUnit = NewProduct.getMeasuredUnit();
		
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
						
			//Statement is used to write queries. Read more about it.
			statement = connection.prepareStatement("INSERT INTO Item VALUES (NULL, ?, ?, ?, ?, ?)");
			
			//ItemID = statement.setInt("Item_ID");
			statement.setString(1, Type);
			statement.setString(2, ProductName);
			statement.setFloat(3, ProductPrice);
			statement.setInt(4, ProductQty);
			statement.setString(5, MeasuredUnit);
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate();
			
			if(result == 1) {
				
				//displays the information of the newly added item to the inventory
				System.out.println("Added the following item to the inventory successfully"); 
				System.out.println("Item_ID: " + ItemID ); 
				System.out.println("Type: " + Type ); 
				System.out.println("Name: " + ProductName );
				System.out.println("Price: " + ProductPrice ); 
				System.out.println("Quantity: " + ProductQty ); 
				System.out.println("Unit: " + MeasuredUnit ); 
			
			} else {
				
				System.out.println("Failed to add new item. Please try again later."); 
				
			}
			statement.close();
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
		
	}

	public void removeItem(int ItemID) {

		Connection connection = null;
		Statement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
			
			//Statement is used to write queries. Read more about it.
			statement = connection.createStatement();
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate("DELETE FROM Item WHERE Item_ID=" + ItemID);
			
			if(result == 1) {
				
				System.out.println("\nItem with ID " + ItemID + " removed from the inventory");				
				
			} else {

				System.out.println("Failed to remove the Item from the inventory. Please try again later");				
				
			}
			
			statement.close();
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
	}

	public void updateDescription(Product Item) {
		
		int Item_ID = Item.getProductID();
		String ProductName = Item.getProductName();
		
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
						
			//Statement is used to write queries. Read more about it.
			statement = connection.prepareStatement("UPDATE user SET Description=? WHERE Item_ID=?");
			
			statement.setString(1, ProductName);
			statement.setInt(2, Item_ID);
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate();
			
			if(result == 1) {
				
				//displays the information of the newly added item to the inventory
				System.out.println("Updated the description of the following item in the inventory successfully"); 
				System.out.println("\nItem with ID " + Item_ID + " is updated with the following description: " + ProductName);
			
			} else {
				
				System.out.println("Failed to add new item. Please try again later."); 
				
			}
			
			statement.close();
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
	}

	public void updatePrice(Product Item) {

		int Item_ID = Item.getProductID();
		float ProductPrice = Item.getProductPrice();
		
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
						
			//Statement is used to write queries. Read more about it.
			statement = connection.prepareStatement("UPDATE user SET Price=? WHERE Item_ID=?");
			
			statement.setFloat(1, ProductPrice);
			statement.setInt(2, Item_ID);
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate();
			
			if(result == 1) {
				
				//displays the information of the newly added item to the inventory
				System.out.println("Updated the price of the following item in the inventory successfully"); 
				System.out.println("\nItem with ID " + Item_ID + " is updated with the following price: $ " + ProductPrice);
			
			} else {
				
				System.out.println("Failed to update the price of an item. Please try again later."); 
				
			}
			
			statement.close();
			
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
	}

	public void updateQty(Product Item) {

		int Item_ID = Item.getProductID();
		int ProductQty = Item.getProductQty();
		
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
						
			//Statement is used to write queries. Read more about it.
			statement = connection.prepareStatement("UPDATE user SET Quantity=? WHERE Item_ID=?");
			
			statement.setInt(1, ProductQty);
			statement.setInt(2, Item_ID);
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate();
			
			if(result == 1) {
				
				//displays the information of the newly added item to the inventory
				System.out.println("Updated the quantity of the following item in the inventory successfully"); 
				System.out.println("\nItem with ID " + Item_ID + " is updated with the following quantity: " + ProductQty);
			
			} else {
				
				System.out.println("Failed to update the Quantity of an item. Please try again later."); 
				
			}
			
			statement.close();
				
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
	}
	
	public void updateUnit(Product Item) {

		int Item_ID = Item.getProductID();
		String ProductUnit = Item.getMeasuredUnit();
		
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			//establishing connection
			connection = DatabaseConnection.createConnection();
						
			//Statement is used to write queries. Read more about it.
			statement = connection.prepareStatement("UPDATE user SET Unit=? WHERE Item_ID=?");
			
			statement.setString(1, ProductUnit);
			statement.setInt(2, Item_ID);
			
			//Fetching all the records and storing in a resultSet.
			int result = statement.executeUpdate();
			
			if(result == 1) {
				
				//displays the information of the newly added item to the inventory
				System.out.println("Updated the unit of the following item in the inventory successfully"); 
				System.out.println("\nItem with ID " + Item_ID + " is updated with the following unit: " + ProductUnit);
			
			} else {
				
				System.out.println("Failed to update the Unit of an Item. Please try again later."); 
				
			}
			
			statement.close();			
			
		} catch (SQLException sqlException) {
			
			sqlException.printStackTrace();
			
		}finally {
			
			try {
				
				connection.close();
				
			} catch (SQLException e) {

				e.printStackTrace();
				
			}
			
		}
		
	}

}
